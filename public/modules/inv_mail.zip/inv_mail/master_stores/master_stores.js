var app = angular.module('ebs2App');
app.controller('master_storesCtrl', function ($scope, $http, $routeParams, $location) {
})